//Handler 클래스
//파싱 대상이 되는 xml을 분석하여 각 노드마다 알맞는 이벤트를 발생시켜 개발자로 하여금 적절한 처리를 할 수 있는 기회를 줌
//노드 : 시작태그, 끝나는태그, 내용, 속성 등을 의미함

package parse.xml;

import java.util.ArrayList;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

//파싱 대상이 되는 xml을 분석하여 각 노드마다 알맞는 이벤트를 발생시켜
//개발자로 하여금 적절한 처리를 할 수 있는 기회를 준다
public class MyHandler extends DefaultHandler {

	// 필드 선언
	ArrayList<Food> list; // ArrayList
	Food food; // DTO
	boolean isName = false; // 현재 실행부가 name 태그를 지났는지 표시
	boolean isPrice = false; // 현재 실행부가 price 태그를 지났는지 표시

	// @Override : 문서 시작을 알아챔
	public void startDocument() throws SAXException {
		System.out.println("문서시작");
	}

	// @Override : 시작태그를 알아챔
	public void startElement(String uri, String localName, String tag, Attributes attributes) throws SAXException {
		// 매개변수의 'qName'을 직관적인 'tag'로 바꿔주었음
		System.out.print("<" + tag + ">");

		// ArrayList를 생성하여 DTO 담음
		if (tag.equals("foodList")) { // 'foodList' 태그를 만나면, ArrayList를 생성
			list = new ArrayList<Food>();
		} else if (tag.equals("food")) { // 'food' 태그를 만나면 DTO 한개를 생성
			food = new Food();
		} else if (tag.equals("name")) {
			isName = true;
		} else if (tag.equals("price")) {
			isPrice = true;
		}
	}

	// @Override : 내용 노드를 알아챔
	public void characters(char[] ch, int start, int length) throws SAXException {
		// 부대찌개를 food에 넣어줘야 함
		String content = new String(ch, start, length); // 배열, 배열의시작, 배열길이
		System.out.print(content); // 줄바꿈 안하기로 함

		// DTO에 값을 채우되, 현재 true인 변수만
		if (isName) { // 현재 실행부가 name 태그를 지나갔다면
			food.setName(content);
		} else if (isPrice) { // 현재 실행부가 price 태그를 지나가는지 표시해줌
			food.setPrice(Integer.parseInt(content));
		}
	}

	// @Override : 끝태그를 알아챔
	public void endElement(String uri, String localName, String tag) throws SAXException {
		System.out.println("</" + tag + ">");

		// name이 한개 더 있기 때문에 현재 실행부가 name 태그를 지나갔다면 원상태로 되돌려 놓음
		if (tag.equals("name")) {
			isName = false;

			// price이 한개 더 있기 때문에 현재 실행부가 price 태그를 지나갔다면 원상태로 되돌려 놓음
		} else if (tag.equals("price")) {
			isPrice = false;

			// food이 한개 더 있기 때문에 현재 실행부가 food 태그를 지나갔다면 원상태로 되돌려 놓음
		} else if (tag.equals("food")) {

			// 하나의 음식이 완성된 시점이므로 }를 만나 내용이 사라지기 전에 ArrayList에 DTO 담음
			list.add(food);
		}
	}

	// @Override : 문서 끝을 알아챔
	public void endDocument() throws SAXException {
		System.out.println("문서 끝");

		System.out.println("담겨진 음식 수 : " + list.size());

		for (int i = 0; i < list.size(); i++) {
			Food food = list.get(i);
			System.out.println("음식명 : " + food.getName() + ", 가격 : " + food.getPrice());
		}
	}
}