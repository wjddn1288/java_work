package parse.xml;

import java.io.File;
import java.io.IOException;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.SAXException;

/*
 자바언어에서 xml을 파싱하는 방법
 1) DOM 파싱 : 태그마다 1:1 대응하는 객체를 메모리에 생성하므로,
 					요즘같은 스마트폰이 활성화된 개발분야에서는 잘 쓰지 않는다
 
 2) SAX 파싱 : 발견되는 태그마다 이벤트를 발생시켜 주는 파싱방식
  */
public class XMLApp {
	// 자바 확장 패키지 XML에 내장되어 있기에 다운받을 필요 없이 가져다 쓰면 됨
	// 이때, 메모리에 바로 new 하지 못하고 GOF의 패턴 중 팩토리 패턴으로 생성해야 함
	public static void main(String[] args) {
		//GOF의 패턴 중 팩토리 패턴으로 생성
		SAXParserFactory factory=SAXParserFactory.newInstance(); //static 메서드일 뿐! 싱글턴은 아님
		try {
			SAXParser saxParser=factory.newSAXParser(); // 파싱 객체를 생성해야 함
			String path="C:/java_workspace2/data/NetworkApp/res/food.xml"; // 앞서 생성해준 food.xml 파일
			saxParser.parse(new File(path), new MyHandler()); // 이벤트를 발생시키는 핸들러
		} catch (ParserConfigurationException e) {
			e.printStackTrace();
		} catch (SAXException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
