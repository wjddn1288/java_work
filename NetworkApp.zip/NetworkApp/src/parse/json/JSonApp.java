package parse.json;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class JSonApp {
	/* JSON은 프로그래밍 언어가 아니라 단지 문자열에 불과하다 */
	public static void main(String[] args) { // 자바는 JSON을 이해못함
		// 문장이 길기 때문에 StringBuffer 사용하고 마지막에 toString 해줄 예정
		// pets 배열에 [] 사용한 이유 : JSON은 자바스크립트 객체 표기법이기 때문에 JS 규칙을 따름
		StringBuffer sb = new StringBuffer();

		// json 표기법은 사실 Map이다!!
		sb.append("{");
		sb.append("\"name\" : \"철수\",");
		sb.append("\"age\" : 29,");
		sb.append("\"hasPet\" : true,");
		sb.append("\"pets\" :[");
		sb.append("{");
		sb.append("\"name\" : \"원조\"");
		sb.append("\"type\" : \"고양이\"");
		sb.append("},");
		sb.append("{");
		sb.append("\"name\": \"마찌\"");
		sb.append("\"type\" : \"고양이\"");
		sb.append("}");
		sb.append("]");
		sb.append("}");

		System.out.println(sb.toString());
		// 위의 문자열을 실제 객체처럼 사용하려면, 문자열을 객체화시키는 과정이 (즉 해석) 필요한데,
		// 프로그래밍 분야에서는 이러한 과정을 "파싱한다" 라고 표현한다!!

		// JS에서는 JSON이 내장 객체로 들어있기에 {}를 바로 JSON으로 인식하여 사용하기 가능하지만
		// JAVA에서 위의 문자열을 실제 객체로 사용하기 위해서는 객체화 시키는 해석 과정(parsing)이 필요함
		JSONParser jsonparser = new JSONParser();

		// 파싱을 하고나면 문자열에 불과했던 데이터를 실제 객체로 변환해준다!
		try {
			Object obj = jsonparser.parse(sb.toString()); // (반환형 Object)parse()메소드로 parsing해줌
			JSONObject json = (JSONObject) obj; // Object가 너무 상위객체이니 하위객체 JSONObject로 형변환해줌
			System.out.println(json.get("name")); // JSON은 사실 MAP임(키=name / 값=철수)
			System.out.println(json.get("age")); // 29
			System.out.println(json.get("hasPet")); // true
			JSONArray array = (JSONArray) json.get("pets"); // Object가 너무 상위객체이니 하위객체 중 JSONArray로 형변환해줌
			System.out.println("반려동물의 수는 : " + array.size()); // 반려동물의 수는 : 2
			for (int i = 0; i < array.size(); i++) {
				JSONObject pet = (JSONObject) array.get(i);
				System.out.println("반려동물의 이름은 : " + pet.get("name")); // 반려동물의 이름은 : 원조 / 마찌
			}
		} catch (ParseException e) {
			e.printStackTrace();
		}
	}
}