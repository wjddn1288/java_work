package network.multi.katalk;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import network.domain.ChatMember;

public class LoginPage extends Page {
	JLabel la_title;
	JTextField t_id;
	JTextField t_pass;
	JButton bt_login;
	JButton bt_join;

	ChatMemberDAO chatMemberDAO; // 오라클인지 mysql인지 미리 결정하지 말자!!
	// 굉장히 많이 쓰이고 추천하는 방식임 -> 아무나 다 가르킬수 있어서 코드가 유연해진다.
	// 결국 호출되는 메서드는 자식의 메서드가 호출되고, 이러한 객체지향의 개발 방법을 다형성이라 한다.

	public LoginPage(ClientMain clientMain) {
		super(clientMain); // ClientMain을 받아옴
		chatMemberDAO = new OracleChatMemberDAO();
		// chatMemberDAO.selectAll();

		la_title = new JLabel("KaKaoTalk");
		t_id = new JTextField();
		t_pass = new JTextField();
		bt_login = new JButton("로그인");
		bt_join = new JButton("회원가입");

		la_title.setPreferredSize(new Dimension(350, 200));
		la_title.setFont(new Font("Verdana", Font.BOLD, 45));
		la_title.setHorizontalAlignment(SwingConstants.CENTER); // setHorizontalAlignment 가운데 정렬

		Dimension d = new Dimension(350, 30);
		t_id.setPreferredSize(d);
		t_pass.setPreferredSize(d);

		add(la_title);
		add(t_id);
		add(t_pass);

		add(bt_login);
		add(bt_join);

		setBackground(Color.YELLOW);

		// 로그인 처리
		bt_login.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				loginCheck();
			}
		});

		// 회원가입 버튼과 리스너 연결
		bt_join.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				clientMain.showHide(ClientMain.JOINPAGE); // 클라이언트 메인꺼임 page 클래스에 매겨변수 각 페이지에 super호출
			}
		});
	}

	// 디자인영역이라서 퇴근시간을 위해 로직은 여기다가 짜지 말자!!
	public void loginCheck() {
		// id,pass를 하나의 DTO에 담아서 전달하기!!
		ChatMember chatMember = new ChatMember(); // empty 상태 DTO
		chatMember.setId(t_id.getText());
		chatMember.setPass(t_pass.getText());

		chatMember = chatMemberDAO.select(chatMember); // select에 null이면 실패임
		if (chatMember == null) {
			JOptionPane.showMessageDialog(this, "로그인 정보가 올바르지 않습니다.");
		} else {
			JOptionPane.showMessageDialog(this, "로그인 성공");
			// clientMain에 사용자 정보 보관해두기!!
			clientMain.chatMember = chatMember;

			// 채팅 창 보여주기
			clientMain.showHide(ClientMain.CHATPAGE);
			ChatPage chatPage = (ChatPage) clientMain.page[ClientMain.CHATPAGE]; // 메인에 배열에 있으니까!!
			chatPage.connect(); // 로그인페이지에서 채팅페이지 호출!!
		}
	}
}
