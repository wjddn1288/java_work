//Local 컴퓨터에서 원격지의 데이터를 url로 접근하여 실행중인 자바 프로그램으로 읽어오기
//-> 네트워크 객체(HttpURLConnection)와 문자기반 입력스트림(Reader)이 필요함

//패키지 선언
package io.network;

//패키지 연결
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

//클래스 선언
public class GetRemoteData {
	// 메인메소드 선언
	public static void main(String[] args) {

		BufferedReader buffr = null;
		InputStreamReader reader = null;
		InputStream is = null; // finally에서 사용 위해

		// 1. 원격지에 접속하기 : HttpURLConnection이 필요함
		// public abstract class HttpURLConnection이라 생성할 수 없으니 URL에서 얻어오기로 함
		// URL의 생성자 URL(String spec)
		// URL의 메소드 openConnection() : URLConnection을 반환함
		// HttpURLConnection은 URLConnection을 상속받음
		try {
			URL url = new URL("https://www.naver.com");
			URLConnection uc = url.openConnection();
			HttpURLConnection con = (HttpURLConnection) uc; // 강제타입변환
			// -> 원격지 웹서버에 접속하여 url로 해당 주소의 자원을 다운받아 오는 객체임
			
			//원격지의 웹서버에 요청을 시도할 수 있는 객체
			//더쉽게 말해서 웹서버에 접속하여 해당 주소의 자원을 다운받아 오는 객체
			con.setRequestMethod("GET"); // GET 방법으로 URL을 요청함(추후에 배울 예정)
			con.setRequestProperty("Content-type", "text/html"); // text/xml, application/json, image/jpg
			int code = con.getResponseCode(); // 서버측의 응답처리 성공여부(200=성공 / 401=실패)
			System.out.println("서버측의 응답처리 성공여부 : " + code);

			// 2. 스트림 생성하여 데이터 가져오기
			is = con.getInputStream();
			reader = new InputStreamReader(is);
			buffr = new BufferedReader(reader);

			String data = null;
			while (true) {
				data = buffr.readLine();
				if (data == null)
					break;
				System.out.println("읽어들인 data : " + data);
			}
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally { // stream 사용 후에는 반드시 닫아줘야 함
			if (buffr != null) {
				try {
					buffr.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			if (reader != null) {
				try {
					reader.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			if (is != null) {
				try {
					is.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
}
