//패키지 선언
package io.basic;

//패키지 연결
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

//클래스 선언
public class MemoApp extends JFrame {
	// 필드 선언
	JButton bt;
	JButton bt_open; // JFileChooser 띄움
	JFileChooser chooser;
	JButton bt_save; // JTextArea 내용을 파일에 저장함
	JTextArea area;
	JScrollPane scroll;
	String path = "C:/java_workspace2/data/NetworkApp/res/memo.txt";
	File file; // 현재 열어놓은 파일

	// ------------------------------------------------------------------------------------------------

	// 생성자 선언
	public MemoApp() {
		// 생성
		bt = new JButton("파일읽기");
		bt_open = new JButton("파일열기");
		bt_save = new JButton("저장하기");
		chooser = new JFileChooser();
		area = new JTextArea();
		scroll = new JScrollPane(area);
		// 디자인
		setLayout(new FlowLayout());
		scroll.setPreferredSize(new Dimension(570, 320));
		// 부착
		add(bt);
		add(bt_open);
		add(bt_save);
		add(scroll);

		// 윈도우 세팅
		setVisible(true);
		setSize(600, 400);
		setDefaultCloseOperation(EXIT_ON_CLOSE);

		// 파일읽기 버튼에 이벤트 부착
		bt.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// loadData();
				loadData2();
			}
		});

		// 파일열기 버튼에 이벤트 부착
		bt_open.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				openFile();
			}
		});

		// 저장하기 버튼에 이벤트 부착
		bt_save.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				save();
			}
		});
	}

	// ------------------------------------------------------------------------------------------------

	// 메소드 선언 : 바이트기반 입력스트림 이용할 경우
	public void loadData() {

		FileInputStream fis = null; // =바이트기반 스트림 : 바이너리 데이터용(문자 이해 못함)

		try {
			fis = new FileInputStream(path);
			int data = -1; // 데이터가 없는 상태

			// FileInputStream.read() : 바이트 단위로 읽어 반환함. 더이상 읽을 게 없으면 대기상태에 빠짐
			// blocks : 대기상태에 빠짐
			data = fis.read();
			System.out.println("data : " + (char) data); // j (byte로 반환되기에 char형으로 변환하여 출력함)
			data = fis.read();
			System.out.println("data : " + (char) data); // a
			data = fis.read();
			System.out.println("data : " + (char) data); // v
			data = fis.read();
			System.out.println("data : " + (char) data); // a
			data = fis.read();
			System.out.println("data : " + (char) data); // (공백)
			data = fis.read();
			System.out.println("data : " + (char) data); // 프? -> X 못읽음

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally { // stream은 사용 후 반드시 닫아줘야 함
			if (fis != null) {
				try {
					fis.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
	}

	// 메소드 선언 : 문자기반 입력스트림 이용할 경우
	public void loadData2() {

		FileInputStream fis = null; // =바이트기반 스트림 : 바이너리 데이터용(문자 이해 못함). 문자기반 스트림을 사용하기 위해 기본으로 필요함
		InputStreamReader reader = null; // =문자기반 스트림 : 문자 데이터용

		try {
			fis = new FileInputStream(path);
			reader = new InputStreamReader(fis);
			int data = -1;

			while (true) {
				data = reader.read();
				if (data == -1)
					break;
				area.append(Character.toString((char) data));
				// append() 매개변수가 string형이므로 byte형인 data를 char형으로 변환한 다음 한번 더 변환함
			}

			/*
			 * -----------------------------------------------------------이거는 왜 실행 안되는걸까?
			 * while문에서 읽어들여 -1된 상태라 그런가? // InputStreamReader.read() : 문자 단위로 읽어 반환함. data
			 * = reader.read(); System.out.println("data : "+(char) data); // j data =
			 * reader.read(); System.out.println("data : "+(char) data); // a data =
			 * reader.read(); System.out.println("data : "+(char) data); // v data =
			 * reader.read(); System.out.println("data : "+(char) data); // a data =
			 * reader.read(); System.out.println("data : "+(char) data); // (공백) data =
			 * reader.read(); System.out.println("data : "+(char) data); // 프 data =
			 * reader.read(); System.out.println("data : "+(char) data); // 로 data =
			 * reader.read(); System.out.println("data : "+(char) data); // 그 data =
			 * reader.read(); System.out.println("data : "+(char) data); // 래 data =
			 * reader.read(); System.out.println("data : "+(char) data); // 머
			 */
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (reader != null) {
				try {
					reader.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			if (fis != null) {
				try {
					fis.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}

	// 메소드 선언 : 파일열기
	public void openFile() {
		int result = chooser.showOpenDialog(this); // JFileChooser로 선택한 옵션 반환함
		if (result == JFileChooser.APPROVE_OPTION) {
			file = chooser.getSelectedFile(); // 멤버변수로 빼줌
			// FileReader : InputStreamReader의 자식
			FileReader reader = null;
			BufferedReader buffr = null;
			// FileReader로 하나씩 읽기 힘드니 BufferedReader로 업그레이드

			try {
				reader = new FileReader(file);
				buffr = new BufferedReader(reader);
				// int data=-1;
				String data = null;
				int count = 0; // 읽어들인 횟수 알아보기 위해

				while (true) {
					/*
					 * data = reader.read(); if(data==-1)break;
					 * area.append(Character.toString((char)data)); count++; // -> FileReader로 하나씩
					 * 읽기 힘드니 BufferedReader로 업그레이드 해보자
					 */
					data = buffr.readLine(); // 줄 단위로 읽어들임. 반환형 String
					if (data == null)
						break;
					area.append(data + "\n"); // 한 줄 단위 데이터기에 출력시마다 개행해야 함
					count++;
				}

				System.out.println("읽어들인 횟수는 : " + count); // 1042에서 -> 641로 줄었음
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			} finally {
				if (reader != null) {
					try {
						reader.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
				if (buffr != null) {
					try {
						buffr.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}
		}
	}

	// 메소드 선언 : area 내용 저장하기
	public void save() {
		FileWriter writer = null; // 파일을 대상으로 한 문자 기반 출력스트림(주체는 컴퓨터!!)
		BufferedWriter buffw = null; // 버퍼처리 된 문자 기반 출력스트림

		try {
			writer = new FileWriter(file);// 덮어쓰기 -> file을 0byte로 만듦
			buffw = new BufferedWriter(writer); // file 크기 0byte임. 업그레이드용
			buffw.write(area.getText());
			JOptionPane.showMessageDialog(this, "저장완료");
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (buffw != null) {
				try {
					buffw.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			if (writer != null) {
				try {
					writer.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}

	// 메인메소드 선언
	public static void main(String[] args) {
		new MemoApp();
	}
}