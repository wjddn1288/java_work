//키보드&모니터를 대상으로 한 stream
//키보드 관련한 입력스트림은 뭘까? KeyboardReader? X -> InputStream
//키보드 관련된 입력스트림은 OS(시스템)가 켜질 때 자동으로 생성되기에 개발자는 생성된 스트림을 OS(시스템)를 통해 얻어오면 됨
//또한 그렇기 때문에 finally에서 닫으면 안됨
package io.basic;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;

//지금까지 우리가 다루어왔던 입출력은 파일에 국한되었으나,
//사실 실행중인 프로그램으로 데이터를 입력받거나, 출력하는것은 파일뿐만 아니라
//상당한 다양한 대상으로 이우러질 수 있다.. 이번 예제에서는 키보드를 대상으로 입력을 처리해보자!
public class KeyBoardApp {
	// sun에서는 추후 어떤 디바이스가 개발될지 예측할수 없으므로 KeyBoard를 비롯한 다양한
	// 디바이스들에 대한 스트림 처리 클래스를 각각 정의할 수 없기때문에 스트림 객체 중
	// 가장 추상적이면서 최상위 객체인 InputStream과 OutputStream으로 이 문제를 해결하고 있다.

	public static void main(String[] args) {
		// public abstract class InputStream : 추상클래스이기 때문에 생성하는 것이 아니라 얻어와야 함
		// InputStream은 System에 필드(in)로 소속되어 있음
		// public static final InputStream 'in'

		// 그냥 입력스트림...

		// 키보드 관련된 스트림은 개발자가 생성하지 않아도 이미 생성되어 있기 때문에 그냥 얻어오면 된다...
		// 키보드 스트림은 OS 가 켜질때 생성되며, 개발자는 단지 생성된 스트림을 얻어오면 된다...
		InputStream is = System.in; // 입력 바이트기반 키보드 입력을 제어하는 입력스트림

		// 문자기반으로 업그레이드
		InputStreamReader reader = new InputStreamReader(is);

		// 한줄씩 처리하도록 업그레이드
		BufferedReader buffr = new BufferedReader(reader);

		// public abstract class OutputStream : 추상클래스이기 때문에 생성하는 것이 아니라 얻어와야 함
		// OutputStream은 System에 필드(out)로 소속되어 있음
		// public static final PrintStream 'out'
		// -> 우리가 사용하던 System.out.println(data) : System 클래스의 필드 out이 갖고 있는 println 메소드
		// PrintStream은 OutputStream을 상속받음

		// 바이트 기반 출력스트림
		OutputStream os = System.out; // 아웃스트림 최상위 객체, 모니터 출력을 제어하는 출력스트림
		OutputStreamWriter writer = new OutputStreamWriter(os); // 문자기반으로 업그레이드

		BufferedWriter buffw = new BufferedWriter(writer); // 버퍼처리 출력스트림으로,한줄씩 처리하도록 업그레이드

		String data = null; // 업그레이드

		try {
			// 키보드에서 입력한 문자들을 버퍼에 쌓아가다가
			// 사용자가 문자열의 끝임을 알리는 '엔터'를 치면
			// 실행중인 프로그램으로 데이터가 들어옴
			while (true) { // 한글자 이상 입출력 할 수 있도록 반복문
				// data = is.read(); // (반환형 int)커서 깜박이며 대기함. 키보드로 입력하면 대기 풀림
				data = buffr.readLine(); // 업그레이드
				System.out.println(data);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
}
