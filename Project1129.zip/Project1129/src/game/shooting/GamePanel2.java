package game.shooting;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;

import javax.swing.JPanel;

public class GamePanel2 extends JPanel{
	Thread loopThread;
	BgObject bgObject;
	Hero hero;
	
	public GamePanel2() {
		setPreferredSize(new Dimension(900,500));
		setBackground(Color.YELLOW);
		
		createBg();
		createHero();
		createEnemy();
		
		loopThread = new Thread() {
			public void run() {
				gameLoop();
				while(true) {
					try {
						Thread.sleep(10);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			}
		};
		loopThread.start();
	}
	public void paintComponent(Graphics g) {
		Graphics2D g2= (Graphics2D)g;
		
		g2.clearRect(0, 0, 900, 500);
		bgObject.render(g2);
		hero.render(g2);
		
		for(int i=0; i< bulletList.size();i++) {
			Bullet bullet = bulletList.get(i);
			bullet.render(g2);
		}
		for(int i=0; i<enemyList.size();i++) {
			Enemy enemy=enemyList.get(i);
			enemy.render(g2);
		}
	}
}
