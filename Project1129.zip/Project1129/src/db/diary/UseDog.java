package db.diary;

public class UseDog {
	
	public static void main(String[] args) {
		Dog d= Dog.getInstance();
		System.out.println(d);
	}
}
