package db.diary;

import java.sql.PreparedStatement;
import java.sql.SQLException;

/*이 객체에는 DB관련 CRUD 이외의 코드는 두지 않는다
 * 즉 insertm update, delete, select 실행에 대한 코드만 두어야한다.. 즉 쿼리 전담객체이다. 
 * 이러한 목적의 클래스를 가리켜 DAO(Data Access Object)라 한다. 
 * ex) 테이블이 25개라면 DAO도 25개 존재해야한다
 */
public class DiaryDAO {
	DBManager dbManager=DBManager.getInstance();
	
	// CRUD 중 insert 를 정의한다.
	public int insert(Diary diary) {
		PreparedStatement pstmt=null;
		String sql = "insert into diary(diary_idx, yy,mm,dd,content,icon)";
		sql+=" values(seq_diary.nextval, ?,?,?,?,?)";
		try {
			pstmt=dbManager.getConnection().prepareStatement(sql);
			pstmt.setInt(1, );
			pstmt.setInt(2, );
			pstmt.setInt(3, );
			pstmt.setInt(4, );
			pstmt.setInt(5, );
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return 0;
	}
}
