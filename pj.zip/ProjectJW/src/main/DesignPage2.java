package main;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;

import util.DBManager;




public class DesignPage2 extends JFrame {
	// 북쪽 영역
	JPanel p_north;
	JLabel la_logo; // 정우투어
	JButton bt_login, bt_join; // 로그인 버튼

	// 센터 영역
	JPanel p_center, p_mainsearch; // 센터 패널 센터에 나올 패널
	JLabel la_hi, la_img; // 인사말   la_img
	JTextField t_dep, t_arr, t_start, t_end, t_person; // 출발지, 도착지, 가는날, 오는날, 인원수
	JButton bt_search; // 검색 버튼
	ImageIcon icon;
	
	// 텍스트필드 라벨
	JLabel la_dep, la_arr, la_start, la_end, la_person; // 출발지, 도착지, 가는날, 오는날, 인원수

	// 남쪽영역
	JPanel p_south;
	JLabel la_con, la_con2;
	DBManager dbManager= DBManager.getInstance();

	public DesignPage2() {
		// 북쪽영역
		p_north = new JPanel();
		la_logo = new JLabel("JW투어");
		bt_login = new JButton("로그인");
		bt_join = new JButton("회원가입");

		//p_north.setBackground(Color.YELLOW);
		p_north.setPreferredSize(new Dimension(900, 100));
		p_north.setLayout(null);

		la_logo.setBounds(100, 25, 120, 40);
		la_logo.setFont(new Font("Vernada", Font.BOLD, 30));
		la_logo.setForeground(Color.PINK);

		bt_login.setBounds(1020, 25, 75, 40); // setBounds(x, y, w, h)
		bt_join.setBounds(930, 25, 84, 40);

		p_north.add(la_logo);
		p_north.add(bt_login);
		p_north.add(bt_join);
		add(p_north, BorderLayout.NORTH);

		// 센터영역
	    icon=new ImageIcon("res/beach0.jpg"); //뭐 찾고있는거 있음? 
		p_center = new JPanel(); // 이거 실행해봐봐 일단
		p_center.setLayout(null);
		Border border = new LineBorder(Color.GRAY); 
		p_center.setBorder(border);
		
		
		//이미지 가져온 코드 이렇게 했을땐 나왔는데 근데 사이즈 조절이 안됨 
//		try {
//			URL url= new URL("https://cdn.pixabay.com/photo/2016/10/18/21/22/beach-1751455_960_720.jpg");
//			la_img=new JLabel(new ImageIcon(url));
//		} catch (MalformedURLException e1) {
//			e1.printStackTrace(); 
//		}
//		icon=new ImageIcon(); 
//		p_center = new JPanel(); 
//		p_center.setSize(400,600); 	
		
		
		

		p_mainsearch = new JPanel();
		p_mainsearch.setLayout(null);

		Font f = new Font("SanSerif", Font.PLAIN, 25);
		Font f2 = new Font("Dotum", Font.ITALIC, 18);

		la_hi = new JLabel("이제 여행을 시작하세요");
		la_hi.setFont(new Font("SanSerif", Font.BOLD,40));
		la_hi.setBounds(120, 30, 450, 70);// setBounds(x좌표값, y좌표값, w넓이, h높이)
		
		t_dep = new JTextField();
		t_dep.setFont(f);
		t_dep.setBounds(100,130,200,40);
		
		t_arr = new JTextField();
		t_arr.setFont(f);
		t_arr.setBounds(300,130,200,40);
		
		t_start = new JTextField();
		t_start.setFont(f);
		t_start.setBounds(500,130,200,40);

		t_end = new JTextField();
		t_end.setFont(f);
		t_end.setBounds(700,130,200,40);

		t_person = new JTextField();
		t_person.setFont(f);
		t_person.setBounds(900,130,200,40);

		la_dep = new JLabel("출발지");
		la_dep.setFont(f2);
		la_dep.setBounds(110, 80, 80, 70);// setBounds(x, y, w, h)

		la_arr = new JLabel("도착지");
		la_arr.setFont(f2);
		la_arr.setBounds(310, 80, 80, 70);

		la_start = new JLabel("가는 날");
		la_start.setFont(f2);
		la_start.setBounds(510, 80, 80, 70);

		la_end = new JLabel("오는 날");
		la_end.setFont(f2);
		la_end.setBounds(710, 80, 80, 70);

		la_person = new JLabel("인원");
		la_person.setFont(f2);
		la_person.setBounds(920, 80, 80, 70);

		bt_search = new JButton("항공권 검색");
		bt_search.setFont(f);
		bt_search.setForeground(Color.WHITE);
		bt_search.setBackground(Color.PINK);
		bt_search.setBorderPainted(false);
		bt_search.setBounds(900, 180, 200, 50);

		p_mainsearch.setBounds(0, 0, 1200, 250);
		Color b=new Color(128,128,128,122); 
		p_mainsearch.setBackground(b);
		//p_mainsearch.setBackground(Color.LIGHT_GRAY);

		p_mainsearch.add(t_dep);
		p_mainsearch.add(t_arr);
		p_mainsearch.add(t_start);
		p_mainsearch.add(t_end);
		p_mainsearch.add(t_person);

		p_mainsearch.add(la_hi);
		p_mainsearch.add(la_dep);
		p_mainsearch.add(la_arr);
		p_mainsearch.add(la_start);
		p_mainsearch.add(la_end);
		p_mainsearch.add(la_person);
		p_mainsearch.add(bt_search);
		
		//la_img.setSize(1200,900);
//		la_img.setBounds(0, 0, 1200, 900);
		
		p_center.add(p_mainsearch);
//		p_center.add(la_img);
		add(p_center);

		// 남쪽
		p_south = new JPanel();
		p_south.setPreferredSize(new Dimension(1200, 185));
		p_south.setLayout(null);
		
		Font f3 = new Font("SanSerif", Font.PLAIN, 14);
		
		la_con = new JLabel("<HTML><body> 회사 소개  |  이용약관  |  여행약관  |  개인정보처리방침</body></HTML>");
		la_con.setFont(new Font("Verdana", Font.BOLD, 18));
		la_con.setBounds(100, 5, 500, 20);

		la_con2 = new JLabel(
				"<HTML><body>(주)JW투어 | 대표 : 최정우 | 주소 : 서울 마포구 신촌로 176 중앙빌딩 | 사업자등록번호 : 123-12-12345 | 관광사업자 등록번호 제 1111-000000호 <br><br>"
				+ "JW항공이 추천하는 최저가 여행 <br> 최저 운임 항공권 | 서울 출발 항공권 | 제주 출발 항공권 | 부산 출발 항공권 | 청추 출발 항공권 | 대구 출발 항공권 | 광주출발 항공권 <br><br> "
				+ " Fax:02-789-0987 상담센터 : 1577-1114 | E-mail : wjddn7728@gmail.com | mobile : 010-5678-7890 <br>"
				+ "※ 부득이한 사정에 의해 여행일정이 변경되는 경우 사전 동의를 받습니다. <br>Copyrightⓒ JWTour Co.All Right Reserved  </body></HTML>");
		la_con2.setFont(f3);
		la_con2.setBounds(100, 35, 1000, 150);
		p_south.add(la_con);
		p_south.add(la_con2);
		
		add(p_south, BorderLayout.SOUTH);

		setTitle("JWTour");
		setSize(1200, 900);
		setVisible(true);
		//setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				dbManager.release(dbManager.getConnection());
				System.exit(0);
			}
		});
		
		bt_join.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			}
		});
		
		bt_login.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			}
		});
		
		bt_search.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			}
		});
		
	}
	public static void main(String[] args) {
		new DesignPage2();
	}
}
