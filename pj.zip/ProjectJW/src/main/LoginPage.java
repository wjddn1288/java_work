package main;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class LoginPage extends Page {
	JLabel l_title;
	JTextField t_id;
	JTextField t_pass;
	JButton bt_login;
	JButton bt_join;
	
	MemberDAO MemberDAO;
	
	public LoginPage(Main main) {
		super(main);
		MemberDAO = new OracleMemberDAO();
		
		l_title = new JLabel("JWTour");
		t_id = new JTextField();
		t_pass = new JPasswordField();
		bt_login = new JButton("Login");
		bt_join = new JButton("Join");
		
		l_title.setFont(new Font("verdana", Font.BOLD, 45));
		l_title.setPreferredSize(new Dimension(350, 200));
		l_title.setHorizontalAlignment(SwingConstants.CENTER); // 가운데정렬
		
		Dimension d = new Dimension(270, 30); 
		t_id.setPreferredSize(d);
		t_pass.setPreferredSize(d);
		
		Dimension d2 = new Dimension(132, 30); 
		bt_login.setPreferredSize(d2);
		bt_join.setPreferredSize(d2);
		
		add(l_title);
		add(t_id);
		add(t_pass);
		add(bt_login);
		add(bt_join);
		
		setBackground(Color.PINK);
		
		bt_login.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				loginCheck();
			}
		});
		
		bt_join.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				main.showHide(Main.JOINPAGE);
			}
		});
	}
		public void loginCheck() {
			Member member=new Member();
			member.setId(t_id.getText());
			member.setPass(t_pass.getText());
			member=MemberDAO.select(member);
			if(member==null) {
				JOptionPane.showMessageDialog(this, "로그인 정보가 올바르지 않습니다.");
			}else {
				JOptionPane.showMessageDialog(this, "로그인 성공");
				main.member=member;
				main.showHide(Main.DESIGNPAGE);
			}
		}
	}
