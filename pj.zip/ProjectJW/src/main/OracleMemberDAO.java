package main;

import java.net.http.WebSocket.Listener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import util.DBManager;

public class OracleMemberDAO implements MemberDAO {

	DBManager dbManager = DBManager.getInstance();

	public int insert(Member member) {
		Connection con = null;
		PreparedStatement pstmt = null;

		con = dbManager.getConnection();

		String sql = "insert into member(member_idx, id, pass, name)";
		sql += " values(seq_member.vextval, ?, ?, ?)";
		int result = 0;
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, member.getId());
			pstmt.setString(2, member.getPass());
			pstmt.setString(3, member.getName());
			result = pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return result;
	}

	public int update(Member member) {
		return 0;
	}

	public int delete(int member_idx) {
		return 0;
	}

	public Listener selectAll() {
		return null;
	}

	public Member select(int member_idx) {
		return null;
	}

	public Member select(Member member) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		Member obj = null;

		con = dbManager.getConnection();

		String sql = "select * from member id=? and pass=?";
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, member.getId());
			pstmt.setString(2, member.getPass());
			rs = pstmt.executeQuery();

			if (rs.next()) {
				obj = new Member();
				obj.setMember_idx(rs.getInt("member_idx"));
				obj.setId(rs.getString("id"));
				obj.setPass(rs.getString("pass"));
				obj.setName(rs.getString("name"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			dbManager.release(pstmt, rs);
		}
		return null;
	}

}
