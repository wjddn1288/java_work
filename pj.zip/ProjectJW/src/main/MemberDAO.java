package main;

import java.net.http.WebSocket.Listener;

public interface MemberDAO {

	public int insert(Member member); // insert

	public int update(Member member); // update

	public int delete(int member_idx); // delete

	public Listener selectAll(); // 모든 레코드 가져오기

	public Member select(int member_idx); // 한건 가져오기 select~~~~where...idx

	public Member select(Member member); // 한건 가져오기 select~~~~where...idx

}
