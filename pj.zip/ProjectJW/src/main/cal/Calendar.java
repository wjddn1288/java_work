package main.cal;

public class Calendar {
	private int cal_idx;
	private int yy;
	private int dd;
	private int mm;
	public int getCal_idx() {
		return cal_idx;
	}
	public void setCal_idx(int cal_idx) {
		this.cal_idx = cal_idx;
	}
	public int getYy() {
		return yy;
	}
	public void setYy(int yy) {
		this.yy = yy;
	}
	public int getDd() {
		return dd;
	}
	public void setDd(int dd) {
		this.dd = dd;
	}
	public int getMm() {
		return mm;
	}
	public void setMm(int mm) {
		this.mm = mm;
	}
	
}
