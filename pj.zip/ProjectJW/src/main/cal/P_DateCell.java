package main.cal;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.border.Border;
import javax.swing.border.LineBorder;

public class P_DateCell extends P_Cell {
	Color color = Color.WHITE;

	public P_DateCell(String title, int fontSize, int x, int y) {
		super(title, fontSize, x, y);
		Border border = new LineBorder(Color.DARK_GRAY);
		setBorder(border);

		this.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				if (color == Color.WHITE) {
					color = Color.PINK;
				} else {
					color = Color.white;
				}
				repaint();
			}
		});
	}

	protected void paintComponent(Graphics g) {
		Graphics2D g2 = (Graphics2D) g;
		g2.clearRect(0, 0, 120, 120);
		// 배경색 적용하기
		g2.setColor(color);
		g2.fillRect(0, 0, 100, 100);

		g2.setColor(Color.DARK_GRAY);
		g2.drawString(title, x, y);
	}
}
