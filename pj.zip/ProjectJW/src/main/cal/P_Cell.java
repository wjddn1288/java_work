package main.cal;

import javax.swing.JPanel;

public class P_Cell extends JPanel {
	String title;
	int fontSize;
	int x,y;
	
	public P_Cell(String title,int fontSize,int x, int y) {
		this.title = title;
		this.fontSize=fontSize;
		this.x=x;
		this.y=y;
	}
	
}
