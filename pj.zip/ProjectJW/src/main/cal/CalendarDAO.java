package main.cal;

import util.DBManager;

public class CalendarDAO {
	DBManager dbManager = DBManager.getInstance();
}
