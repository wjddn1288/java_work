package main.cal;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Calendar;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;


public class CalMain extends JFrame {
	JPanel p_center;
	JPanel p_title;
	JPanel p_dayOfWeek; 
	JPanel p_dayOfMonth; 
	JButton bt_prev;
	JLabel la_title;// 현재 년월
	JButton bt_next;
	
	//요일
	P_DayCell[] p_dayCells = new P_DayCell[7];
	String[] dayTitle = { "Sun", "Mon", "Tue", "Wed", "Thur", "Fri", "Sat" };

	//날짜
	P_DateCell[][] p_dateCells = new P_DateCell[6][7];
	
	// 현재 사용자가 보게 될 날짜 정보!!
	Calendar currentObj = Calendar.getInstance();
	
	public CalMain() {
		p_center = new JPanel();
		p_title = new JPanel();
		p_dayOfWeek = new JPanel();
		p_dayOfMonth = new JPanel();
		bt_prev = new JButton("이전");
		la_title = new JLabel("2022년 12월");
		bt_next = new JButton("다음");
		
		p_center.setPreferredSize(new Dimension(550, 500));
		p_title.setPreferredSize(new Dimension(550, 50));
		Font f = new Font("SanSerif", Font.PLAIN, 18);
		
		bt_prev.setFont(f);
		la_title.setFont(f);
		bt_next.setFont(f);
		
		p_title.add(bt_prev);
		p_title.add(la_title);
		p_title.add(bt_next);
		
		p_center.add(p_title);
		p_center.add(p_dayOfWeek);
		p_center.add(p_dayOfMonth);

		p_dayOfWeek.setPreferredSize(new Dimension(550, 30));
		p_dayOfWeek.setBackground(Color.PINK);
		p_dayOfWeek.setLayout(new GridLayout(1, 7));

		p_dayOfMonth.setPreferredSize(new Dimension(550, 400));
		p_dayOfMonth.setBackground(Color.PINK);
		p_dayOfMonth.setLayout(new GridLayout(6, 7));
		
		add(p_center);
		
		createDayOfWeek(); // 요일 출력
		createDayOfMonth();// 날짜 출력
		calculate(); //날짜처리
		
		setSize(630, 560);
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		//이전월
		bt_prev.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// 현재 날짜 
				int mm = currentObj.get(Calendar.MONTH);
				currentObj.set(Calendar.MONTH, mm - 1);
				calculate();
			}
		});
		
		// 다음월
		bt_next.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// 현재 날짜
				int mm = currentObj.get(Calendar.MONTH);
				currentObj.set(Calendar.MONTH, mm + 1);
				calculate();
			}
		});
	}
	
		//요일 출력
		public void createDayOfWeek() {
			for(int i=0; i< p_dayCells.length; i++) {
				p_dayCells[i]=new P_DayCell(dayTitle[i],15,20,20);
				p_dayOfWeek.add(p_dayCells[i]);
			}
		}
		
		//날짜 출력
		public void createDayOfMonth() {
			for (int i = 0; i < p_dateCells.length; i++) {// 층수
				for (int a = 0; a < p_dateCells[i].length; a++) {// 호수
					p_dateCells[i][a] = new P_DateCell("", 10, 30, 10);
					// 패널에 부착
					p_dayOfMonth.add(p_dateCells[i][a]);
				}
			}
		}
		
		public int getStartDayOfWeek() {
			Calendar cal = Calendar.getInstance();
			int yy = currentObj.get(Calendar.YEAR); // 년도
			int mm = currentObj.get(Calendar.MONTH); // 월
			cal.set(yy, mm, 1); // 1일로 조작하자!!
			int day = cal.get(Calendar.DAY_OF_WEEK);// 요일 추출!!
			return day;
		}
		
		public int  getLastDayOfMonth() {
			Calendar cal= Calendar.getInstance();
			int yy = currentObj.get(Calendar.YEAR);
			int mm = currentObj.get(Calendar.MONTH);
			cal.set(yy, mm+1, 0); //조작 완료!!
			int date = cal.get(Calendar.DATE);
			return date;
		}
		
		// 제목을 출력한다
		public void printTitle() {
			int yy = currentObj.get(Calendar.YEAR);
			int mm = currentObj.get(Calendar.MONTH);
			String str = yy + "년" + (mm + 1) + "월";
			la_title.setText(str);
		}
		
		//새로 출력이 아닌 글씨만 바꾼다
		public void printDate() { 
			int n=0;
			int d=0;  
			for(int i=0; i<p_dateCells.length; i++) {			
				for(int a=0; a<p_dateCells[i].length; a++) {
					P_DateCell cell = p_dateCells[i][a];
					n++;
					if(n >=getStartDayOfWeek() && d<getLastDayOfMonth()) {
						d++;
						cell.title=Integer.toString(d);
					}else {
						cell.title="";
					}
				}
			}
			p_dayOfMonth.repaint();
		}
		public void calculate() {
			printTitle(); // 제목출력
			printDate(); //날짜출력
		}
		public static void main(String[] args) {
			new CalMain();
		}
	}

