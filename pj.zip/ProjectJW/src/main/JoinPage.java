package main;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class JoinPage extends Page {
	JLabel la_title;
	JTextField t_id;
	JTextField t_pass;
	JTextField t_name;
	JButton bt_login;
	JButton bt_join;
	
	MemberDAO memberDAO;
	
	public JoinPage(Main main) {
		super(main);
		memberDAO = new OracleMemberDAO();
		
		la_title = new JLabel("회원가입 페이지");
		t_id = new JTextField();
		t_pass = new JTextField();
		t_name = new JTextField();
		bt_login = new JButton("로그인");
		bt_join = new JButton("회원가입");
		
		la_title.setPreferredSize(new Dimension(350, 300));
		la_title.setFont(new Font("Verdana", Font.BOLD, 35));
		la_title.setHorizontalAlignment(SwingConstants.CENTER); // 가운데 정렬
		
		Dimension d = new Dimension(350, 30);
		t_id.setPreferredSize(d);
		t_pass.setPreferredSize(d);
		t_name.setPreferredSize(d);

		setPreferredSize(new Dimension(700, 600));
		
		add(la_title);
		add(t_id);
		add(t_pass);
		add(t_name);
		add(bt_login);
		add(bt_join);
		
		setBackground(Color.PINK);
		
		// 로그인 버튼과 리스너 연결
		bt_login.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				login();
			}
		});

		// 회원가입 버튼과 리스너 연결
		bt_join.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				regist();
			}
		});
	}
	
	public void login() {
		main.showHide(Main.LOGINPAGE);
	}
	
	public void regist() {
		Member member = new Member(); // empty 상태인 DTO
		member.setId(t_id.getText());
		member.setPass(t_pass.getText());
		member.setName(t_name.getText());

		int result = memberDAO.insert(member);
		if (result > 0) {
			JOptionPane.showMessageDialog(this, "가입 성공!!");
		}

	}
}
