package main;

import java.awt.Dimension;

import javax.swing.JPanel;

public class Page extends JPanel {
	Main main;
	
	public Page(Main main) {
		this.main = main;

		this.setPreferredSize(new Dimension(400, 500));

	}
}
