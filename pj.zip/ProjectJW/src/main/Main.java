package main;

import java.awt.event.WindowAdapter;
import javax.swing.JPanel;
import util.DBManager;

public class Main {
	JPanel container;
	
	Page[] page = new Page[3];
	public static final int DESIGNPAGE=0;
	public static final int LOGINPAGE = 1;
	public static final int JOINPAGE = 2;

	Member member;
	DBManager dbManager = DBManager.getInstance();

	public Main() {
		container=new JPanel();
		//DesignPage designPage = new DesignPage();
		page[0] = new LoginPage(this);
		page[1] = new JoinPage(this);

//		for(int i=0; i< page.length; i++) {
//			container.add(page[i]);
//		}
//		add(container);
		
		showHide(DESIGNPAGE);
		
	}
	
	public void showHide(int n) {
		for(int i=0; i<page.length; i++) {
			if(n==i) {
				page[0].setVisible(true);
			}else {
				page[1].setVisible(false);
			}
		}
	}
	
	
	public static void main(String[] args) {
		new Main();
	}
}
